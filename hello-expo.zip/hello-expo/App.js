import React from 'react';
import { Text, View } from 'react-native';
import { styles } from './styles';

function App() {
  return (
    <View style={styles.container}>
      <Text>
        Try e 🎉
      </Text>
    </View>
  );
}

export default App;